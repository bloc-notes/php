<div style="padding-top:50px"></div>
<footer>
    <p>
        &copy; QWERTY <span class="sPiedPage">Une idée original d'Andy Chen, Francis Chartrands, Gabriel Roy et Philippe Doyon</span>
    </p>
</footer>
