<?php
   // --- Établissement de la connexion avec mySQL
   $strNomAdmin = "qwerty";
   $strMotPasseAdmin = "Secret21186";
?>
