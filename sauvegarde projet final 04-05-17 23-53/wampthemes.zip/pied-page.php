<footer>
    <p>
        &copy; QWERTY <span class="sPiedPage">Une idée original d'Andy Chen, Francis Chartrands, Gabriel Roy et Philippe Doyon</span>
    </p>
</footer>
</body>   
</html>