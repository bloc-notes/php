<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="styleSheet.css">
<script language="javascript" type="text/javascript" src="generalScript.js"></script>
<meta charset="UTF-8">
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
</head>
<body>


<header>
   <form id="frmSaisie" method="" action="">
      <div id="divEntete" class="sEntete">

         <p class="sTitreApplication" >
            QWERTY
            
         </p>
           <p class=" rainbow" >
            L

         </p>      
      </div>
           </header>


<div align="center">
	<table>
		  <tr>

		    <td colspan="3" style="text-align:center"><br><span style="font-weight:bold;font-size: 60px;font-family:Arial Black;">QWERTY</span><br></td>
	  </tr>
	  <tr>
	    <td colspan="2"><br><span style="font-weight:bold">Connectez-vous avec un compte existant</span><br></td> <td rowspan="6"></td>
	  </tr>
	    <tr>
	   <td><input type="text" class="textbox" placeholder="Courriel"><br></td> 
	  </tr>
	  <tr>
	    <td><input type="password" class="textbox" placeholder="Mot de passe"><br></td>
	  </tr>
	    <tr>
	    <td colspan="2"><input type="button" style="font-weight:bold" onClick="changePage('affichageAnnonce.php')" class="btn" value="Se connecter">&nbsp;&nbsp;&nbsp;<a href="changerPasswordAnonyme.php" style="color: rgb(66,165,220);">mot de passe oublié?</a><br></td>
	  </tr> 
	  <tr>
	    <td colspan="2"><br>Pas enregistré?<br><span style="font-weight:bold;">Créer un compte Qwerty</span></td>
	  </tr> 
	  <tr>
	    <td colspan="3" style="padding-bottom: 40px;"><input type="button" class="btn" style="font-weight:bold" value="Créer un compte" onClick="changePage('enregistrement.php')"></td>
	  </tr> 
	</table >
</div>
<?php require_once("footer.php"); ?>
</body>
</html>
