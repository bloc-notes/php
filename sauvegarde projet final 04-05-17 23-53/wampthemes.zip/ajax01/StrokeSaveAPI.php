<?php
$data = $_REQUEST['stroke'];
  $mysqli = new mysqli('localhost','root','','ajax01');
$myArray = array();
if ($result = $mysqli->query("INSERT INTO strokes (stroke)
VALUES ('$data')")) {
error_log("Insert Success $data ;", 0);
}
else
{
	error_log("Insert Failed $data ;", 0);
}
$mysqli->close();

?>