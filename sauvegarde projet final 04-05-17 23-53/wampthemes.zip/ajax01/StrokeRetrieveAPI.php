<?php 
//SELECT * FROM table WHERE id = @last_id;
  //--------------------------------------------------------------------------
  // Example php script for fetching data from mysql database
  // by Trystan Lea : openenergymonitor.org : GNU GPL
  //--------------------------------------------------------------------------
  $host = "localhost";
  $user = "root";
  $pass = "";

  $databaseName = "ajax01";
  $tableName = "strokes";
  $mysqli = new mysqli('localhost','root','','ajax01');
$myArray = array();
if ($result = $mysqli->query("SELECT stroke FROM strokes;")) {

    while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}


$mysqli->close();

?>