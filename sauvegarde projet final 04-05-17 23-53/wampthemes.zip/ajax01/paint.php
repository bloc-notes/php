<!DOCTYPE HTML>
<html>
  <head>
  <script language="javascript" type="text/javascript" src="jquery.js"></script>
    <style>
      body {
        margin: 0px;
        padding: 0px;
      }
    </style>
  </head>
  <body onload="/*initializeCanvas()*/">
<input type="button" id="myBtn" onclick="save()" value="Upload to mySQL">
<input type="button" id="myBtn" onclick="retrieve()" value="Retrieve from mySQL">
<input type="button" id="myBtn" onclick="initializeCanvas()" value="initialize canvas from mySQL">
<div id="output">this element will be accessed by jquery and this text will be replaced</div>
<div id="output1">this element will be accessed by jquery and this text will be replaced</div>
  	<div id="paint">
  		<canvas id="myCanvas" width="300" height="300"></canvas>
	</div>
    <script id="source" language="javascript" type="text/javascript">
    setInterval(function(){ 
    initializeCanvas();   
}, 300);
function save()
{
  var testCanvas = document.getElementById("myCanvas");
  var canvasData = testCanvas.toDataURL();
  name = canvasData;
  status = "status";
  alert("saving");
      $.ajax({
      type: 'POST',
      url: 'PaintSaveAPI.php',                  //the script to call to get data          
      data: {status: status, name: name},                        //you can insert url argumnets here to pass to api.php for example "id=5&parent=6"
      dataType: 'json',                //data format      
      success: function(data)          //on recieve of reply
      {
        alert("Saved");
      } 
    });
  $('#output').html("<br />" + testCanvas.toDataURL());  


}
function initializeCanvas()
{
$.ajax({                                      
      url: 'StrokeRetrieveAPI.php',                  //the script to call to get data          
      data: "",
      type: 'POST',
      dataType: 'json',
      async: true,                //data format      
      success: function(data)          //on recieve of reply
      {
       
      for (u = 0; u < data.length; u++) 
      {     

                Strokes = JSON.stringify(data[u]);
                obj = JSON.parse(Strokes);
                var strStokes = ""+obj.stroke;
                var strokeArray = strStokes.split(',');
                $('#output').html(strokeArray.toString());
                var canvas = document.getElementById('myCanvas');
                var ctx = canvas.getContext('2d');
                ctx.lineWidth = 3;
                ctx.lineJoin = 'round';
                ctx.lineCap = 'round';
                ctx.strokeStyle = '#00CC99';

                ctx.beginPath();
                for (i = 0; i < strokeArray.length; i++) 
                { 
                ArraySingularStroke = strokeArray[i].split(';');
                ctx.lineTo(ArraySingularStroke[0], ArraySingularStroke[1]);
                ctx.stroke();
                }
      }



      } 
    });

}
function saveStroke(arrayXY)
{
  var stroke = arrayXY.toString();
      $.ajax({
      type: 'POST',
      url: 'StrokeSaveAPI.php',                  //the script to call to get data          
      data: {stroke: arrayXY.toString()},                        //you can insert url argumnets here to pass to api.php for example "id=5&parent=6"
      dataType: 'json',                //data format      
      success: function(data)          //on recieve of reply
      {
        alert("Saved");
      } 
    });
}
function retrieve()
{
  var URLcanvas = "";
$.ajax({                                      
      url: 'PaintRetrieveAPI.php',                  //the script to call to get data          
      data: "",
      type: 'POST',
      dataType: 'json',
      async: true,                //data format      
      success: function(data)          //on recieve of reply
      {
        var id = data[0];              //get id
        var type = data[1];           //get name
        var canvas = data[2];
        URLcanvas = ((JSON.stringify(data[5])).substring(10)).slice(0, -1);
        $('#output').html(URLcanvas);  
        var canvas = document.getElementById('myCanvas');
        var ctx = canvas.getContext('2d');
        var myImage = new Image();
        myImage.src = URLcanvas;
        alert(1+URLcanvas);
        ctx.drawImage(myImage, 50, 50);
      } 
    });

}

var arrayXY = [];
var canvas = document.getElementById('myCanvas');
var ctx = canvas.getContext('2d');
 
var painting = document.getElementById('paint');
var paint_style = getComputedStyle(painting);
  //ctx.canvas.width  = window.innerWidth;
  //ctx.canvas.height = window.innerHeight;
var mouse = {x: 0, y: 0};
 
canvas.addEventListener('mousemove', function(e) {
  mouse.x = e.pageX - this.offsetLeft;
  mouse.y = e.pageY - this.offsetTop;
}, false);

ctx.lineWidth = 3;
ctx.lineJoin = 'round';
ctx.lineCap = 'round';
ctx.strokeStyle = '#00CC99';
 
canvas.addEventListener('mousedown', function(e) {//START OF PATH
    ctx.beginPath();
    ctx.moveTo(mouse.x, mouse.y);
// $('#output').html("X:"+mouse.x+" Y:"+mouse.y);
 //arrayXY.push("{"+mouse.x+","+mouse.y+"}");

    canvas.addEventListener('mousemove', onPaint, false);
}, false);
 
canvas.addEventListener('mouseup', function() {///END OF PATH
    canvas.removeEventListener('mousemove', onPaint, false);
    saveStroke(arrayXY);
    arrayXY = [];
}, false);
 
var onPaint = function() { //MOVEMENTS
   $('#output').html("X:"+mouse.x+" Y:"+mouse.y);
   arrayXY.push(mouse.x+";"+mouse.y);
   $('#output1').html(arrayXY.toString());
    ctx.lineTo(mouse.x, mouse.y);
    ctx.stroke();
};

    </script>
  </body>
</html>  