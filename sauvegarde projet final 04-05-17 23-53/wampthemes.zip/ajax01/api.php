<?php 

  //--------------------------------------------------------------------------
  // Example php script for fetching data from mysql database
  // by Trystan Lea : openenergymonitor.org : GNU GPL
  //--------------------------------------------------------------------------
  $host = "localhost";
  $user = "root";
  $pass = "";

  $databaseName = "ajax01";
  $tableName = "variables";

  //--------------------------------------------------------------------------
  // 1) Connect to mysql database
  //--------------------------------------------------------------------------
  //include 'DB.php';
  //error_log("TESTING1 TESTING1 TESTING1", 0);
  //$con = mysql_connect($host,$user,$pass);
  //error_log("TESTING2 TESTING2 TESTING2 $con ;", 0);
  //$dbs = mysql_select_db($databaseName, $con);
/*
  $con = mysqli_connect("localhost","root","","ajax01");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  error_log("Connection failed;", 0);
  }
  else
  {
    error_log("Connection success;", 0);
  }

  //--------------------------------------------------------------------------
  // 2) Query database for data
  //--------------------------------------------------------------------------
  //$result = mysql_query("SELECT * FROM $tableName");            //query
  //$array = mysql_fetch_row($result);                          //fetch result    

  //--------------------------------------------------------------------------
  // 3) echo result as json 
  //--------------------------------------------------------------------------
  echo json_encode($array);
*/
  $mysqli = new mysqli('localhost','root','','ajax01');
$myArray = array();
if ($result = $mysqli->query("SELECT * FROM variables")) {

    while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}

$result->close();
$mysqli->close();

?>
