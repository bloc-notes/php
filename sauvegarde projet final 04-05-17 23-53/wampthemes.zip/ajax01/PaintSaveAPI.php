<?php
$data = $_REQUEST['name'];
  $mysqli = new mysqli('localhost','root','','ajax01');
$myArray = array();
if ($result = $mysqli->query("INSERT INTO canvas (Type,Canvas)
VALUES ('Canvas','$data')")) {
error_log("Insert Success $data ;", 0);
}
else
{
	error_log("Insert Failed $data ;", 0);
}
$mysqli->close();

?>