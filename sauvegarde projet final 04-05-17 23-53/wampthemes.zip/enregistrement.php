<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<link rel="stylesheet" href="styleSheet.css">
<script language="javascript" type="text/javascript" src="generalScript.js"></script>
<body>
<?php require_once("header.php"); ?>
<div align="center" style="padding-top:40px">
	<table>
	  <tr>
	    <td rowspan="6">	
	    <br><span style="font-weight:bold">Bienvenue dans la création de votre compte Qwerty</span><br><br> 
	    <span style="font-weight:bold">Accédez à vos achats</span><br>
	    Et affichez l'historique de vos commandes<br><br>

	    <span style="font-weight:bold">Gérer les produits de votre entreprise</span><br>
	    Et les distribuer aux utilisateurs finaux
	    </td>
	    <td colspan="2"><br><span style="font-weight:bold">Inscrivez-vous sur QWERTY</span><br></td> <td rowspan="6"></td>
	  </tr>
	  <tr>
	   <td><input type="text" class="textbox" placeholder="Courriel"><br></td> 
	  </tr>
	    <tr>
	   <td><input type="text" class="textbox" placeholder="Confirmez votre courriel"><br></td> 
	  </tr>
	  <tr>
	    <td><input type="password" class="textbox" placeholder="Mot de passe"><br></td>
	  </tr>
	  <tr>
	    <td><input type="password" class="textbox" placeholder="Confirmez votre mot de passe"><br></td>
	  </tr>
	    <tr>
	    <td colspan="2"><input type="button" style="font-weight:bold" class="btn" value="Soumettre" onClick="changePage('PleaseValidate.php')">&nbsp;&nbsp;&nbsp;<br></td>
	  </tr> 

	</table>
</div>
<?php require_once("footer.php"); ?>
</body>
</html>
